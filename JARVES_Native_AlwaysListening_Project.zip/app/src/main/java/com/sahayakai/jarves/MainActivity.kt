package com.sahayakai.jarves

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var toggle: Switch
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(40,50,40,30)}
        val title=TextView(this).apply{text="JARVES AI";textSize=30f}
        val info=TextView(this).apply{text="Hey JARVES बोलकर assistant को जगाएँ";textSize=16f}
        toggle=Switch(this).apply{text="JARVES Background Listening";textSize=18f}
        val settings=Button(this).apply{text="AI Backend Settings"}
        val google=Button(this).apply{text="Google"}
        val yt=Button(this).apply{text="YouTube"}
        val wa=Button(this).apply{text="WhatsApp"}
        box.addView(title);box.addView(info);box.addView(toggle);box.addView(settings)
        box.addView(google);box.addView(yt);box.addView(wa);setContentView(box)

        toggle.setOnCheckedChangeListener { _, on ->
            if(on) startJarves() else stopService(Intent(this,JarvesService::class.java))
        }
        settings.setOnClickListener { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
        google.setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))) }
        yt.setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))) }
        wa.setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("whatsapp://"))) }
    }

    private fun startJarves(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.RECORD_AUDIO),20); toggle.isChecked=false; return
        }
        ContextCompat.startForegroundService(this,Intent(this,JarvesService::class.java))
        Toast.makeText(this,"JARVES ON — “Hey JARVES” बोलें",Toast.LENGTH_LONG).show()
    }
}