package com.sahayakai.jarves

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import java.util.*

class JarvesService: Service(), RecognitionListener {
    private lateinit var recognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private val channel="jarves"
    private var active=true

    override fun onCreate(){
        super.onCreate()
        val nm=getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(channel,"JARVES",NotificationManager.IMPORTANCE_LOW))
        val n=Notification.Builder(this,channel).setContentTitle("JARVES AI").setContentText("Hey JARVES के लिए सुन रहा है").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if(Build.VERSION.SDK_INT>=34) startForeground(7,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(7,n)
        tts=TextToSpeech(this){ tts.language=Locale("hi","IN") }
        recognizer=SpeechRecognizer.createSpeechRecognizer(this);recognizer.setRecognitionListener(this);listen()
    }

    private fun listen(){
        if(!active)return
        val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false)
        }
        try{recognizer.startListening(i)}catch(_:Exception){Handler(Looper.getMainLooper()).postDelayed({listen()},1500)}
    }

    override fun onResults(b:Bundle?){
        val text=b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase(Locale("hi","IN")) ?: ""
        if(text.contains("hey jarves")||text.contains("हे जार्वेस")||text.contains("हे जार्विस")||text.contains("जार्वेस")){
            val cmd=text.replace("hey jarves","").replace("हे जार्वेस","").replace("हे जार्विस","").replace("जार्वेस","").trim()
            if(cmd.isNotEmpty()) execute(cmd) else say("जी, बताइए।")
        }
        Handler(Looper.getMainLooper()).postDelayed({listen()},700)
    }

    private fun execute(c:String){
        when{
            c.contains("youtube")||c.contains("यूट्यूब")->{
                startActivity(Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://www.youtube.com")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));say("YouTube खोल रहा हूँ।")}
            c.contains("whatsapp")||c.contains("व्हाट्सएप")->{
                startActivity(Intent(Intent.ACTION_VIEW,android.net.Uri.parse("whatsapp://")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));say("WhatsApp खोल रहा हूँ।")}
            c.contains("google")||c.contains("गूगल")||c.contains("सर्च")->{
                startActivity(Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://www.google.com/search?q="+android.net.Uri.encode(c))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));say("Google पर खोज रहा हूँ।")}
            c.contains("wifi")||c.contains("वाईफाई")->{
                startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));say("Wi-Fi settings खोल रहा हूँ।")}
            c.contains("bluetooth")||c.contains("ब्लूटूथ")->{
                startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));say("Bluetooth settings खोल रहा हूँ।")}
            c.contains("settings")||c.contains("सेटिंग")->{
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));say("Settings खोल रहा हूँ।")}
            else->say("मैंने आपकी बात सुनी। इस command के लिए AI backend जोड़ना होगा।")
        }
    }
    private fun say(s:String){tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"jarves")}
    override fun onDestroy(){active=false;try{recognizer.destroy()}catch(_:Exception){};tts.shutdown();super.onDestroy()}
    override fun onBind(i:Intent?)=null
    override fun onReadyForSpeech(p:Bundle?){};override fun onBeginningOfSpeech(){};override fun onRmsChanged(r:Float){};override fun onBufferReceived(b:ByteArray?){};override fun onEndOfSpeech(){}
    override fun onError(e:Int){Handler(Looper.getMainLooper()).postDelayed({listen()},1200)}
    override fun onPartialResults(b:Bundle?){};override fun onEvent(t:Int,p:Bundle?){}
}